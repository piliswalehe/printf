Printf collaboration project by Kevin Erick and Veronica Ndemo
